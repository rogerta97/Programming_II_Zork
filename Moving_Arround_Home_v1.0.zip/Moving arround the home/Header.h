#ifndef _HEADER_H_
#define _HEADER_H_ 

void moving(char*[][4], int**, int, int, char*[5], char*[5]);
int** place_objects(void); 

#endif